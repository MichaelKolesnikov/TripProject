<?php
// подключаемся в БД MySQL
$server = "localhost";
$user = "root";
$pass = "";
$db = "ajax";

print 'dsds <p>';


$con1=mysqli_connect($server, $user, $pass) or die ("Не могу подключиться к MySQL Server");
mysqli_select_db($con1,$db) or die ("Не могу подключится к MySQL БД");
// Запрос на вставку переденных из формы данных в нашу таблицу

$query = "INSERT INTO ajax (`field1`, `field2`) VALUES ('".$_GET['field1']."', '".$_GET['field2']."')";
echo  $query;



mysqli_query($con1,$query) 


//or die(mysql_error());



?>

