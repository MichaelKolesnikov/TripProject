INSERT INTO Lab (number) VALUES
('Lab001'),
('Lab002'),
('Lab003');


INSERT INTO Handing (lab_id, laboratory_work_id, student_id) VALUES
(1, 1, 1),
(2, 2, 2),
(3, 3, 3),
(1, 4, 4),
(2, 5, 5),
(1, 5, 1),
(2, 5, 2), 
(3, 1, 3),
(1, 4, 4),
(2, 2, 5);

INSERT INTO Report (laboratory_work_id, student_id, passed)
SELECT laboratory_work_id, student_id, 
       CASE 
           WHEN laboratory_work_id % 2 = 0 THEN TRUE
           ELSE FALSE
       END AS passed
FROM Handing;

