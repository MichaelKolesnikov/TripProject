# 1) Получить всех студентов, находящихся на 4ом курсе;
SELECT id FROM Student WHERE Student.course = 4;

# 2) Выяснить в какой лаборатории заданный студент по плану выполняет заданную именем
# лабораторную работу (например, лабораторную работу «Изучение плазмы в открытом поле»).
CREATE TEMPORARY TABLE S AS
    SELECT 
        h.id,
        lw.description,
        m.first_name,
        l.number
    FROM
        Handing h
    JOIN
        Man m ON m.id = h.student_id
    JOIN
        Lab l ON l.id = h.lab_id
    JOIN
        LaboratoryWork lw ON lw.id = h.laboratory_work_id;
SELECT number FROM S WHERE first_name = "Петр" AND description = "Изучение плазмы в открытом поле";

