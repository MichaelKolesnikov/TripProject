CREATE TABLE IF NOT EXISTS Man (
    id INT PRIMARY KEY AUTO_INCREMENT,
    first_name VARCHAR(64) NOT NULL,
    last_name VARCHAR(64) NOT NULL,
    email VARCHAR(64),
    phone VARCHAR(16)
);

CREATE TABLE IF NOT EXISTS Student (
    id INT PRIMARY KEY AUTO_INCREMENT,
    FOREIGN KEY (id) REFERENCES Man(id),
    record_book_number INT NOT NULL,
    course INT NOT NULL CHECK (course BETWEEN 1 AND 5)
);

CREATE TABLE IF NOT EXISTS Lab (
    id INT PRIMARY KEY AUTO_INCREMENT,
    number VARCHAR(8) NOT NULL
);

CREATE TABLE IF NOT EXISTS LaboratoryWork (
    id INT PRIMARY KEY AUTO_INCREMENT,
    description TEXT
);

CREATE TABLE IF NOT EXISTS Handing (
    id INT PRIMARY KEY AUTO_INCREMENT,
    lab_id INT,
    laboratory_work_id INT,
    student_id INT,
    FOREIGN KEY (lab_id) REFERENCES Lab(id),
    FOREIGN KEY (laboratory_work_id) REFERENCES LaboratoryWork(id),
    FOREIGN KEY (student_id) REFERENCES Student(id)
);

CREATE TABLE IF NOT EXISTS Report (
    id INT PRIMARY KEY AUTO_INCREMENT,
    laboratory_work_id INT,
    student_id INT,
    passed BOOLEAN NOT NULL,
    FOREIGN KEY (laboratory_work_id) REFERENCES LaboratoryWork(id),
    FOREIGN KEY (student_id) REFERENCES Student(id)
);

