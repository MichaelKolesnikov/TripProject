CREATE TABLE IF NOT EXISTS TransferType (
    id SERIAL PRIMARY KEY,
    name VARCHAR(255) NOT NULL UNIQUE
);

INSERT INTO TransferType (name) VALUES 
('economy'),
('comfort'),
('premium');

CREATE TABLE IF NOT EXISTS Transport (
    id SERIAL PRIMARY KEY,
    type VARCHAR(255) NOT NULL UNIQUE
);

INSERT INTO Transport (type) VALUES
('Автобус'),
('Такси'),
('Лимузин'),
('Внедорожник'),
('Минивэн'),
('Автомобиль'),
('Вертолет'),
('Катер'),
('Лодка');
